import { Injectable } from '@angular/core';
import { Http, Response, RequestOptions, Headers } from '@angular/http';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';

import { People } from './people';

const PEOPLE: People[] = [];

@Injectable()
export class PeopleService {
  private baseUrl: string = 'http://localhost:3000/api';
  constructor(private http: Http) {
  }
  private getHeaders() {
    const headers = new Headers();
    headers.append('Accept', 'application/json');
    return headers;
  }
  getAll() {
    return this.http.get(this.baseUrl + '/people', { headers: this.getHeaders()})
      .map((res: Response) => res.json());
  }
  get(id: Number): Observable<People> {
    const people$ = this.http
      .get(`${this.baseUrl}/people/${id}`, {headers: this.getHeaders()})
      .map((res: Response) => res.json());
    return people$;
  }
  delete(id: string): Observable<People>  {
    console.log ('Current person is' , id );
    const people$ = this.http
      .delete(`${this.baseUrl}/people/${id}`, {headers: this.getHeaders()})
      .map((res: Response) => res.json());
    return people$;
  }
  create(people: People): Observable<Response> {
    console.log('in create service ');
    const headers = new Headers({ 'Content-Type': 'application/json' });
    const options = new RequestOptions({ headers: headers });
    const body = JSON.stringify(people);
    console.log(JSON.stringify(people))
    return this.http.post(`${this.baseUrl}/people/`, body, options)
      .map(
        res => {
          const response = res.json();
          console.log('following response from server after saving  = ' + JSON.stringify(response));
          return response;
        }
      ).catch(this.handleError);
  }
  // update(people: People): Observable<Response> {
  //   console.log('i m in update method');
  //   const headers = new Headers({ 'Content-Type': 'application/json' });
  //   const options = new RequestOptions({ headers: headers });
  //   const body = JSON.stringify(people);
  //   console.log('following response from server before saving  = ' + JSON.stringify(people));
  //   return this.http.put(`${this.baseUrl}/people/`, people, options )
  //     .map(
  //       res => {
  //         const response = res.json();
  //         console.log('following response from server after saving  = ' + JSON.stringify(response));
  //         return response;
  //       }
  //     ).catch(this.handleError);
  // }

  update(people: People): Observable<Response>  {
    const headers = new Headers({ 'Content-Type': 'application/json' });
    const options = new RequestOptions({ headers: headers });

    console.log('following response from server before saving  = ' + JSON.stringify(people));
    return this.http.put(`${this.baseUrl}/people/${people.id}`, JSON.stringify(people), options)
      .map(
          res => {
            const response = res.json();
            console.log('following response from server = ' + response);
            return response;
          }
        ).catch(this.handleError);
  }



  private handleError (error: any) {
    const errorMsg = error.message || `Yikes! There was a problem with our hyperdrive device and we couldn't retrieve your data!`
    console.error(errorMsg);
    return Observable.throw(errorMsg);
  }
}


