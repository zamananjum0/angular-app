import { MaxValidatorDirective } from './max-validator.directive';

describe('MaxValidatorDirective', () => {
  it('should create an instance', () => {
    const directive = new MaxValidatorDirective();
    expect(directive).toBeTruthy();
  });
});
