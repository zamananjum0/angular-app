import { Component, OnInit } from '@angular/core';
import { People } from '../people';
import { PeopleService } from '../people.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-people-list',
  templateUrl: './people-list.component.html',
  styleUrls: ['./people-list.component.css']
})
export class PeopleListComponent implements OnInit {
  people: People[];
  sub: any;
  constructor(private route: ActivatedRoute,
              private peopleService: PeopleService,
              private router: Router) { }

  ngOnInit() {
    this.loadPeople();
  }
  loadPeople() {
    console.log('Loading People List');
    this.peopleService.getAll().subscribe(
      data => {
        this.people = data;
        console.log('=========================getPeople========================');
        console.log(this.people);
      },
      err => console.error(err)
    );
  }

  deletePerson(personId) {
    console.log ('Current person is' , personId );
    this.peopleService.delete(personId).subscribe(
      success => {

      },
      err => console.log(err),
      () => {
        console.log('Deleted Successfully');
        this.loadPeople();
      }
    );
  }

}
