export class People {
  id: string;
  name: string;
  height: number;
  weight: number;

  constructor() {
    {
      this.id = '';
      this.name = '';
      this.height = 0;
      this.weight = 0;
    }
  }
}
