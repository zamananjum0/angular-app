import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { PeopleService } from '../people.service';
import { People } from '../people';

@Component({
  selector: 'app-people-details',
  templateUrl: './people-details.component.html',
  styles: []
})
export class PeopleDetailsComponent implements OnInit, OnDestroy {
  professions: string[] = ['jedi', 'bounty hunter', 'princess', 'sith lord'];
  people: People;
  sub: any;

  constructor(private route: ActivatedRoute,
              private peopleService: PeopleService,
              private router: Router) { }

  ngOnInit() {
    this.sub = this.route.params.subscribe(params => {
      const id = params['id'];
      console.log('getting person with id: ', id);
      this.peopleService.get(id).subscribe(
        data => {
          this.people = data;
          console.log('=========================getPerson========================');
          console.log(this.people);
        },
        err => console.error(err)
      );
    });
  }

  ngOnDestroy() {
    this.sub.unsubscribe();
  }

  gotoPeoplesList() {
    let link = ['/people'];
    this.router.navigate(link);
  }

  UpdateDetails() {
      console.log(`${JSON.stringify(this.people)}`);
      this.peopleService.update(this.people);
  }


}


