import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PeopleService } from '../people.service';
import { People } from '../people';

@Component({
  selector: 'app-people-form',
  templateUrl: './people-form.component.html',
  styleUrls: ['./people-form.component.scss']
})
export class PeopleFormComponent implements OnInit {
   people: People[] = [];

   myPerson: People;

  sub: any;
  constructor(private route: ActivatedRoute, private peopleService: PeopleService, private router: Router) {
  }
  ngOnInit() {
    let people = new People();
    this.myPerson = new People();
  }

  gotoPeoplesList() {
    let link = ['/people'];
    this.router.navigate(link);
  }

  savePeople() {
    this.myPerson.id = null;
    console.log(JSON.stringify(this.myPerson));
    this.peopleService.create(this.myPerson)
      .subscribe(
        success => {
          this.people.push(this.myPerson);
          console.log('Saving succefully...!');
          console.log(JSON.stringify(this.myPerson));
          this.gotoPeoplesList();
        },
        err => console.log(err),
      );
  }
}

