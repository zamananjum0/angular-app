import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';

import { AppComponent } from './app.component';
import { PeopleListComponent } from './people-list/people-list.component';
import { PeopleService } from './people.service';
import { PeopleDetailsComponent } from './people-details/people-details.component';

import { AppRoutingModule } from './app-routing.module';
import { MinValidatorDirective } from './min-validator.directive';
import { MaxValidatorDirective } from './max-validator.directive';
import { PeopleFormComponent } from './people-form/people-form.component';


@NgModule({
  declarations: [
    AppComponent,
    PeopleListComponent,
    PeopleDetailsComponent,
    MinValidatorDirective,
    MaxValidatorDirective,
    PeopleFormComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    AppRoutingModule,
  ],
  providers: [PeopleService],
  bootstrap: [AppComponent]
})
export class AppModule { }
