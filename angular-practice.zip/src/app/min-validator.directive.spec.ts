import { MinValidatorDirective } from './min-validator.directive';

describe('MinValidatorDirective', () => {
  it('should create an instance', () => {
    const directive = new MinValidatorDirective();
    expect(directive).toBeTruthy();
  });
});
