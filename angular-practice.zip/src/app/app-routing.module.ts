import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { PeopleListComponent } from './people-list/people-list.component';
import { PeopleDetailsComponent } from './people-details/people-details.component';
import { PeopleFormComponent } from './people-form/people-form.component';

// Route config let's you map routes to components
const routes: Routes = [
  // map '/persons' to the people list component
  {
    path: 'people',
    component: PeopleListComponent,
  },
  // map '/persons/:id' to person details component
  {
    path: 'people/:id',
    component: PeopleDetailsComponent
  },
  {
    path: 'form',
    component: PeopleFormComponent,
  },
  // map '/' to '/persons' as our default route
  {
    path: '',
    redirectTo: '/people',
    pathMatch: 'full'
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
