import { Injectable } from '@angular/core';
import { Http, RequestOptions, Headers } from "@angular/http";
import { Observable } from "rxjs/Observable";
import { RoomType } from "../../Models/RoomType";
import { AppSettings } from "../../AppSettings/AppSettings";


@Injectable()
export class RoomTypeService {

    private appSettings = new AppSettings();

    constructor(private http: Http) { }

    add(roomType) {

        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers });
        let body = JSON.stringify(roomType);
        //body = body.replace('"id":"",',' ');

        return this.http
            .post(`${this.appSettings.baseUrl}/roomtype/`, body, options)
            .map(
            res => {
                const data = res.json();
                return data;
            }
            ).catch(this.handleError);
    }

    edit(roomType) {

        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers });
        let body = JSON.stringify(roomType);


        return this.http
            .put(`${this.appSettings.baseUrl}/roomtype/`, body, options)
            .map(
            res => {
                const data = res.json();
                return data;
            }
            ).catch(this.handleError);
    }

    delete(id: string): Observable<any> {
        return this.http
            .delete(`${this.appSettings.baseUrl}/roomtype/${id}`, { headers: this.getHeaders() })
            .map(
            res => {
                const data = res.json();
                return data;
            }
            ).catch(this.handleError);
    }

    getAll(): Observable<RoomType[]> {

        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers });

        console.log("In GetAll method");

        let roomTypes = this.http
            .get(`${this.appSettings.baseUrl}/roomtype`, options)
            .map(
            res => {
                const data = res.json();

                return data;
            }
            )
        // .catch(this.handleError);
        return roomTypes;
    }


    getHeaders() {
        let headers = new Headers();
        headers.append('Accept', 'application/json');
        return headers;
    }

    private handleError(error: any) {
        // log error
        // could be something more sofisticated
        console.log("In Error Console");
        let errorMsg = error.message || `Yikes! There was a problem with our hyperdrive device and we couldn't retrieve your data!`
        console.error(errorMsg);

        // throw an application level error
        return Observable.throw(errorMsg);
    }

}
