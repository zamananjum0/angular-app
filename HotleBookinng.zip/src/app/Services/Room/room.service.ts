import { Injectable } from '@angular/core';
import { Http, Response, RequestOptions, Headers } from '@angular/http';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';

import { Room } from '../../Models/Room';
import { RoomType } from '../../Models/RoomType';
import { RoomDay } from '../../Models/RoomDay';
import { AppSettings } from "../../AppSettings/AppSettings";


@Injectable()
export class RoomService {

    private appSettings = new AppSettings();
    private http: Http;

    constructor(http: Http) {
        this.http = http;
    }


    update(room) {

        // Remove room-list-type before update because it isn't part of room-list Entity
        room.roomType = null;

        const options = new RequestOptions({ headers: this.getHeaders() });
        const body = JSON.stringify(room);

        // console.log('Updating room-list : ' + JSON.stringify(room-list));
        return this.http
            .put(`${this.appSettings.baseUrl}/room/`, room, options)
            .map(
            res => {
                const data = res.json();
                console.log(data);
                return data;
            }
            ).catch(this.handleError);
    }

    search(rentPerDay = 0,
        maximumGuestsAllowed = 0,
        checkInDate,
        checkOutDate): Observable<any> {

        console.log('service checkInDate = ' + JSON.stringify(checkInDate));
        console.log('service checkOutDate = ' + JSON.stringify(checkOutDate));


        let filterString = 'filter[include][roomType]&filter';

        if (rentPerDay > 0) {
            filterString += '[where][rentPerDay][lte]=' + rentPerDay + '&filter';
        }

        if (maximumGuestsAllowed > 0) {
            filterString += '[where][maximumGuestsAllowed][lte]=' + maximumGuestsAllowed + '&filter';
        }

        if (checkInDate && checkOutDate) {
            // filterString += "[where][availabilityStartDate][gte]="+startDate+"&filter[where][availabilityStartDate][lte]="+startDate  + "&filter";
            // filterString += "[where][availabilityEndDate][gte]=" + endDate + "&[where][availabilityStartDate][lte]=" + endDate + "&[where][availabilityStartDate][lte]=" + startDate + "&[where][availabilityEndDate][gte]=" + startDate;
            // filterString += "[where][availabilityStartDate][lte]=" + startDate + "&[where][availabilityStartDate][lte]=" + endDate + "&filter[where][availabilityEndDate][gte]=" + endDate + "&[where][availabilityEndDate][gte]=" + startDate;
            filterString += '[where][availabilityStartDate][lte]=' + checkInDate + '&[where][availabilityStartDate][lte]=' + checkOutDate + '&filter[where][availabilityEndDate][gte]=' + checkOutDate + '&[where][availabilityEndDate][gte]=' + checkInDate;

        }
        // if(availabilityEndDate) {
        //   filterString += "[where][availabilityEndDate][gte]="+endDate+"&filter[where][availabilityEndDate][lte]="+endDate;
        // }

        return this.http
            .get(`${this.appSettings.baseUrl}/room/${checkInDate}/${checkOutDate}/${maximumGuestsAllowed}/searchRooms`, { headers: this.getHeaders() })
            .map(
            res => {
                const data = res.json();
                return data;
            }
            )
            .catch(this.handleError);
    }

    add(room) {

        // room-list.beginDate = room-list.beginDate.getDate();
        // room-list.endDate = room-list.endDate.getDate();

        const headers = new Headers({ 'Content-Type': 'application/json' });
        const options = new RequestOptions({ headers: headers });
        const body = JSON.stringify(room);

        console.log(room);
        return this.http
            .post(`${this.appSettings.baseUrl}/room/`, body, options)
            .map(
            res => {
                const data = res.json();
                console.log(data);
                return data;
            });
        // ).catch(this.handleError);
    }

    delete(id: string): Observable<any> {
        return this.http
            .delete(`${this.appSettings.baseUrl}/room/${id}`, { headers: this.getHeaders() })
            .map(
            res => {
                const data = res.json();
                console.log(data);
                return data;
            }
            ).catch(this.handleError);
    }

    getAll(): Observable<Room[]> {

        const room = this.http
            .get(`${this.appSettings.baseUrl}/Room`, { headers: this.getHeaders() })
            .map(
            res => {
                return this.toRoomList(res.json());
            }
            )
            .catch(this.handleError);

        return room;
    }


    mapRooms(response: Response): Room[] {
        // The response of the API has a results
        // property with the actual results
        // return response.json().results.map(this.toRoom);
        return null;
    }

    toRoomList(response: any): Room[] {


        const roomList: Room[] = [];

        for (const r of response) {

            console.log('beginDate from APIs: ' + r.beginDate);

            const room = new Room();
            room.id = r.id;
            room.roomTypeId = r.roomTypeId;
            room.price = r.price;
            room.name = r.name;
            room.unitsAvailable = r.unitsAvailable;
            room.minOccupation = r.minOccupation;
            room.maxOccupation = r.maxOccupation;
            room.description = r.description;
            room.isActive = r.isActive;
            room.rank = r.rank;
            // console.log("begin date before moment = " + r.beginDate);

            // room.beginDate = moment(r.beginDate, 'YYYY-MM-DD').toDate();
            // room.endDate = moment(r.endDate, 'YYYY-MM-DD').toDate();

            // console.log("moment beginDate = " + moment(r.beginDate,'YYYY-MM-DD').toDate());
            // console.log("moment endDate = " + moment(r.endDate,'YYYY-MM-DD').toDate());
            room.createdTime = r.createdTime;
            room.modifiedTime = r.modifiedTime;
            room.modifiedById = r.modifiedById;

            if (r.roomType) {
                room.roomType = new RoomType(r.roomType.id, r.roomType.name);
            }
            roomList.push(room);
        }

        return roomList;
    }

    private getHeaders() {
        const headers = new Headers();
        headers.append('Accept', 'application/json');
        return headers;
    }


    getAllRoomDays(roomId): Observable<RoomDay[]> {

        const room = this.http
            .get(`${this.appSettings.baseUrl}/room/${roomId}/roomDays`, { headers: this.getHeaders() })
            .map(
            res => {
                return this.toRoomDayList(res.json());
            }
            )
            .catch(this.handleError);

        return room;
    }

    bookRoom(roomId, checkInDate, checkOutDate): Observable<any> {
        const response = this.http
            .get(`${this.appSettings.baseUrl}/roomDay/${roomId}/${checkInDate}/${checkOutDate}/bookRoom`)
            .map(
            res => {
                console.log('Received Response : ' + res);
                return res.json();
            }
            ).catch(this.handleError);

        return response;
    }

    logRoomBooking(checkInDate, checkOutDate, roomId) {

        console.log('logging room-list booking');

        const headers = new Headers({ 'Content-Type': 'application/json' });
        const options = new RequestOptions({ headers: headers });
        const obj = {
            checkInDate: checkInDate,
            checkOutDate: checkOutDate,
            customerName: 'Marc',
            roomId: roomId
        };
        const body = JSON.stringify(obj);


        return this.http
            .post(`${this.appSettings.baseUrl}/RoomBookings/`, body, options)
            .map(
            res => {
                const data = res.json();
                console.log(data);
                return data;
            }
            ).catch(this.handleError);
    }

    toRoomDayList(response: any): RoomDay[] {

        const roomDayList: RoomDay[] = [];

        for (let r of response) {

            const roomDay = new RoomDay();
            roomDay.id = r.id;
            roomDay.dayDate = new Date(r.dayDate);
            roomDay.price = r.price;
            roomDay.unitsAvailable = r.unitsAvailable;
            roomDay.unitsBooked = r.unitsBooked;
            roomDay.isAvailable = r.isAvailable;
            roomDay.isActive = r.isActive;
            roomDay.createdTime = r.createdTime;
            roomDay.createdById = r.createdById;
            roomDay.modifiedTime = r.modifiedTime;
            roomDay.modifiedById = r.modifiedById;

            roomDayList.push(roomDay);
        }

        return roomDayList;
    }

    handleError(error: any) {
        // log error
        // could be something more sofisticated
        console.log('In Error Console');
        console.log(error);
        const errorMsg = error.message || `Yikes! There was a problem with our hyperdrive device and we couldn't retrieve your data!`
        console.error(errorMsg);

        // throw an application level error
        return Observable.throw(errorMsg);
    }

    updateRoomDays(roomId, beginDate, endDate, unitsAvailable, price): Observable<any> {

        console.log('in update room-list days');

        return this.http
            .get(`${this.appSettings.baseUrl}/RoomDay/${roomId}/${beginDate}/${endDate}/${unitsAvailable}/${price}/changeAvailability/`,
            { headers: this.getHeaders() })
            .map(
            res => {
                const data = res.json();
                console.log(data);
                return data;
            }
            ).catch(this.handleError);
    }
}


