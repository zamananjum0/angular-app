export class RoomType {

    constructor(
        public id: string,
        public name: string) {
    }
}

