import { RoomType } from "./RoomType";

export class Room {

    public id: string;
    public roomTypeId: string;
    public price: number;
    public name: string;
    public unitsAvailable: number;
    public minOccupation: number;
    public maxOccupation: number;
    public description: string;
    public isActive: boolean;
    public rank: number;
    public beginDate: Date;
    public endDate: Date;
    public createdTime: Date;
    public createdById: number;
    public modifiedTime: Date;
    public modifiedById: number;
    public roomType?: RoomType;

    constructor() {
        this.id = "";
        this.roomTypeId = "";
        this.price = 0;
        this.name = "";
        this.unitsAvailable = 0;
        this.minOccupation = 0;
        this.maxOccupation = 0;
        this.description = "";
        this.isActive = true;
        this.rank = 0;
        //this.beginDate = new Date(); Optional
        //this.endDate = new Date();   Optional
        this.createdTime = new Date();
        this.modifiedTime = new Date();
        this.modifiedById = 1;
        this.roomType = new RoomType("", "");
    }

    public cloneObject() {

        let room = new Room();
        room.id = this.id;
        room.roomTypeId = this.roomTypeId;
        room.price = this.price;
        room.name = this.name;
        room.unitsAvailable = this.unitsAvailable;
        room.minOccupation = this.minOccupation;
        room.maxOccupation = this.maxOccupation;
        room.description = this.description;
        room.isActive = this.isActive;
        room.rank = this.rank;
        room.beginDate = this.beginDate;
        room.endDate = this.endDate;
        room.createdTime = this.createdTime;
        room.modifiedTime = this.modifiedTime;
        room.modifiedById = this.modifiedById;
        room.roomType = new RoomType(this.roomType.id, this.roomType.name);
        return room;
    }
}

