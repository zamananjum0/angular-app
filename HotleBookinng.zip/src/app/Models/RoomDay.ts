export class RoomDay {

    public id: string;
    public dayDate: Date;
    public price: number;

    public unitsAvailable: number;
    public unitsBooked: number;
    public isAvailable: boolean;
    public isActive: boolean;
    public createdTime: Date;
    public createdById: number;
    public modifiedTime: Date;
    public modifiedById: number;
    public roomId: number;


    constructor() {

    }
}

