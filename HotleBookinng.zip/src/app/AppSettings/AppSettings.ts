export class AppSettings {

    baseUrl: string;
    constructor() {
        this.baseUrl = "http://localhost:3000/api";
    }
}
