import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import {RoomType} from "../../../../../Models/RoomType";
import {ActivatedRoute, Router} from "@angular/router";
import {RoomService} from "../../../../../Services/Room/room.service";
import {RoomTypeService} from "../../../../../Services/RoomType/room-type.service";

@Component({
  selector: 'app-room-type',
  templateUrl: './room-type-list.component.html',
  encapsulation: ViewEncapsulation.None,
  providers: [RoomTypeService]
})
export class RoomTypeListComponent implements OnInit {

  private roomTypeList: RoomType[];
  errorMessage: string = "";
  private roomTypeService: RoomTypeService;
  private router: Router;
  private route: ActivatedRoute;
  isAddNewRoomTypeFormHidden = true;

  selectedRoomType: RoomType;
  submitButtonText = "";

  constructor(roomTypeService: RoomTypeService, route: ActivatedRoute,
              router: Router ) {
    this.roomTypeService = roomTypeService;
    this.router = router;
    this.route = route;

    this.selectedRoomType = new RoomType("","");
  }

  ngOnInit() {
    this.loadRoomTypes();
  }

  loadRoomTypes() {
    this.roomTypeService
      .getAll()
      .subscribe(
        /* happy path */ roomTypeList => {
          this.roomTypeList = roomTypeList;
          console.log("Fakhar here");
          console.log(roomTypeList);
        },
        /* error path */ errorMessage => this.errorMessage = errorMessage,
        /* onCompleted */ () => console.log(this.roomTypeList));
  }

  saveRoomType() {

    if(this.selectedRoomType.id == "") { //new room-type
      this.roomTypeService
        .add(this.selectedRoomType)
        .subscribe(r => console.log(`saved!!!`),
          error => console.error(""),
          ()=> {
            this.loadRoomTypes();
            this.selectedRoomType = new RoomType("","");
          });
    } else { //Perform Editing

      this.roomTypeService
        .edit(this.selectedRoomType)
        .subscribe(r => console.log(`saved!!!`),
          error => console.error(""),
          ()=> {
            this.loadRoomTypes();
            this.selectedRoomType = new RoomType("","");
            this.submitButtonText = "Add";
          });
    }
  }
  editRoomType(roomType: RoomType) {

    this.selectedRoomType.id = roomType.id;
    this.selectedRoomType.name = roomType.name;
    this.isAddNewRoomTypeFormHidden = false;
    this.submitButtonText = "Edit";
  }

  deleteRoomType(id: string) {

    if(confirm("Are you sure you want to delete Type?")) {
      this.roomTypeService
        .delete(id)
        .subscribe(
          result => this.loadRoomTypes(),
          error => console.error(error)
        );
    }
  }

  showAddNewRoomTypeForm() {
    this.isAddNewRoomTypeFormHidden = false;
    this.submitButtonText = "Add";
    this.selectedRoomType = new RoomType("","");
  }

  gotoRoomsList() {
    const link = ['/rooms'];
    this.router.navigate(link);
  }
}
