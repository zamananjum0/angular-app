import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule} from '@angular/forms';
import {RouterModule, Routes} from '@angular/router';
import {YounieqComponent} from './younieq.component';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import {RoomFormComponent} from './room-form/room-form.component';
import {RoomListComponent} from './room-list/room-list.component';
import {RoomTypeListComponent} from './room-type/room-type-list/room-type-list.component';
import {RoomTypeFormComponent} from './room-type/room-type-form/room-type-form.component';
import {RoomSearchComponent} from './room-search/room-search.component';
import {DefaultComponent} from '../default.component';
import {LayoutModule} from './../../layouts/layout.module';
import {
  AccordionModule,
  ButtonModule,
  CheckboxModule,
  ChipsModule,
  CodeHighlighterModule,
  ColorPickerModule,
  InputMaskModule,
  FieldsetModule,
  GrowlModule,
  InputTextModule,
  MultiSelectModule,
  PanelModule,
  RadioButtonModule,
  SelectButtonModule,
  SplitButtonModule,
  TabViewModule,
} from 'primeng/primeng';

const routes: Routes = [
  {
    path: "",
    component: DefaultComponent,
    children: [
      {
        path: "",
        component: YounieqComponent,
        children: [
          {path: 'room-form', component: RoomFormComponent},
          {path: 'room-list', component: RoomListComponent},
          {path: 'room-type-form', component: RoomTypeFormComponent},
          {path: 'room-type-list', component: RoomTypeListComponent},
          {path: 'room-search', component: RoomSearchComponent},
        ]
      }
    ]
  },
];

@NgModule({
  imports: [
    CommonModule, RouterModule.forChild(routes),
    LayoutModule,
    FormsModule,
    // primeng modules
    ButtonModule,
    CheckboxModule,
    ChipsModule,
    CodeHighlighterModule,
    ColorPickerModule,
    InputMaskModule,
    GrowlModule,
    InputTextModule,
    MultiSelectModule,
    RadioButtonModule,
    SelectButtonModule,
    SplitButtonModule,
    TabViewModule,
    AccordionModule,
    PanelModule,
    FieldsetModule,
    NgbModule.forRoot(),
  ], declarations: [
    YounieqComponent,
    RoomFormComponent,
    RoomListComponent,
    RoomTypeFormComponent,
    RoomTypeListComponent,
    RoomSearchComponent
  ]
})
export class YounieqModule {
}
