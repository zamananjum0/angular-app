import {Component, OnInit, ViewEncapsulation ,AfterViewInit} from '@angular/core';
import {RoomService} from '../../../../Services/Room/room.service';
import {Room} from '../../../../Models/Room';
import { ScriptLoaderService } from '../../../../_services/script-loader.service';
import {ActivatedRoute, Router} from '@angular/router';
import * as moment from 'moment';
// import {IMyDayLabels, IMyDpOptions} from 'mydatepicker';


@Component({
  selector: 'app-room-search',
  templateUrl: './room-search.component.html',
  encapsulation: ViewEncapsulation.None,
  providers: [RoomService]
})
export class RoomSearchComponent implements OnInit {

  rentPerDay: number;
  maximumGuestsAllowed: number;
  // public checkInDate: Date = new Date();// = {date: {year: 2017, month: 10, day: 14}};
  // public checkOutDate: Date =new Date();// = {date: {year: 2017, month: 10, day: 15}};

  public checkInDate: string;
  public checkOutDate: string;

  private roomService: RoomService;
  roomList: Room[];

  constructor(roomService: RoomService, private route: ActivatedRoute,
              private router: Router,private _script: ScriptLoaderService,) {
    this.roomService = roomService;
  }

  ngOnInit() {
  }
    // ngAfterViewInit() {
    //     this._script.load('.m-grid__item.m-grid__item--fluid.m-wrapper',
    //         'assets/demo/default/custom/components/forms/widgets/bootstrap-datepicker.js');
    // }
  searchRooms() {
    console.log('this is a checkin date'+ this.checkInDate);
    console.log('this is a checkout date'+ this.checkOutDate);

    const checkInDate = moment(this.checkInDate, 'YYYY/MM/DD').toDate();
    const checkOutDate = moment(this.checkOutDate, 'YYYY/MM/DD').toDate();

    console.log('In component');
    console.log('checkInDate = ' + checkInDate);
    console.log('checkOutDate = ' + checkOutDate);

    this.roomService
      .search(this.rentPerDay, this.maximumGuestsAllowed, this.checkInDate, this.checkOutDate)
      .subscribe(
        /* happy path */ roomList => {
          console.log('Received following response');
          console.log(roomList.roomDay[0]);
          this.roomList = roomList.roomDay;
        },
        /* error path */ errorMessage => console.error(errorMessage),
        /* onCompleted */ () => console.log('Request Completed'));

  }

  bookRoom(room) {


    // const theBeginDate = new Date(this.checkInDate.date.year, this.checkInDate.date.month, this.checkInDate.date.day);
    // const theEndDate = new Date(this.checkOutDate.date.year, this.checkOutDate.date.month, this.checkOutDate.date.day);

    const checkInDate = moment(this.checkInDate , 'YYYY/MM/DD').toDate();
    const checkOutDate = moment(this.checkOutDate , 'YYYY/MM/DD').toDate();

    console.log('In bookRoom');
    console.log('checkInDate = ' + checkInDate);
    console.log('checkOutDate = ' + checkOutDate);

    this.roomService
      .bookRoom(room.id, checkInDate, checkOutDate)
      .subscribe(
        res => console.log(res),
        error => console.log(error),
        () => {
          console.log('room Booked');
          this.logRoomBooking(checkInDate, checkOutDate, room.id);
        }
      );
  }

  logRoomBooking(checkInDate, checkOutDate, roomId) {
    this.roomService
      .logRoomBooking(checkInDate, checkOutDate, roomId)
      .subscribe(
        res => console.log(res),
        error => console.log(error),
        () => {
          console.log('logRoomBooking Completed');
          alert('room booked');
        }
      );
  }

  gotoRoomsList() {
    const link = ['/rooms'];
    this.router.navigate(link);
  }

  getDateFromJsonString(date) {

    const formattedDate = new Date(date.date.year, date.date.month - 1, date.date.day);
    return formattedDate;
  }

  getJsonStringFromDate(date) {

    if (!date) {
      console.log('Date is null');
      // return  { date: { year: '', month: '', day: ''} };
      return null;
    }
    console.log('Date is not null');
    const array = date.split('-');
    console.log(array);
    let year = '' + array[0];
    year = year.replace('"', '');

    const month = array[1];
    const day = array[2].split('T')[0];

    const obj = {date: {year: year, month: month, day: day}};
    return obj;
  }

}
