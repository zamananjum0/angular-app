import {Component, ElementRef, Input, OnInit, ViewChild, ViewEncapsulation} from '@angular/core';
import {RoomService} from '../../../../Services/Room/room.service';
import { ActivatedRoute, Router } from '@angular/router';
import {Room} from '../../../../Models/Room';
// import {isCombinedNodeFlagSet} from 'tslint';
// import {IMyDpOptions} from 'mydatepicker';
import * as moment from 'moment';

@Component ({
  selector: 'app-room-list',
  templateUrl: './room-list.component.html',
  providers: [RoomService],
  encapsulation: ViewEncapsulation.None,
})

export class RoomListComponent implements OnInit {

  private router: Router;
  private route: ActivatedRoute

  @Input() readOnlyMode: Boolean = false;

  roomList: Room[];
  private roomService: RoomService;

  errorMessage = '';
  isLoading = true;

  isChangeAvailabilityModalHidden = true;

  roomDayList: any;

  selectedRoom: Room; // Will be used to show room Details in Change Availability Popup selected from RoomList.
  selectedRoomIndex = -1;  // room, selected in RoomList to Update Availability

  // public myDatePickerOptions: IMyDpOptions = {
  //   dateFormat: 'dd/mm/yyyy'
  // };
  beginDate: any;
  endDate: any;

  @ViewChild('btnDismissChangeAvailabilityModal') btnDismissChangeAvailabilityModal: ElementRef;

  constructor(roomService: RoomService, route: ActivatedRoute,
              router: Router) {
    this.roomService = roomService;
    this.router = router;
    this.route = route;
    this.selectedRoom = new Room();
    this.selectedRoomIndex = -1;
  }

  ngOnInit() {
    this.loadRooms();
  }

  loadRooms() {
    this.roomService
      .getAll()
      .subscribe(
        /* happy path */ roomList => this.roomList = roomList,
        /* error path */ errorMessage => this.errorMessage = errorMessage,
        /* onCompleted */ () => console.log(this.roomList));
  }

  editRoom() {
    const link = ['/rooms/new'];
    this.router.navigate(link);
  }

  deleteRoom(id: string) {
    if (confirm('Are you sure you want to delete room?')) {
      this.roomService
        .delete(id)
        .subscribe(
          result => this.loadRooms(),
          error => console.error(error)
        );
    }
  }

  addRoom() {
    console.log('Clicked');
  }

  selectRoomRow(index) {

    // 1- Select Row

    this.selectedRoomIndex = index;
    this.selectedRoom = (this.roomList[index]).cloneObject();

    // 2- Load all RoomDays of this room from APIs
    this.loadRoomDaysBy(this.selectedRoom.id);
  }

  loadRoomDaysBy(roomId) {
    this.roomService
      .getAllRoomDays(roomId)
      .subscribe(
        /* happy path */ roomDayList => this.roomDayList = roomDayList,
        /* error path */ errorMessage => this.errorMessage = errorMessage,
        /* onCompleted */ () => console.log(this.roomDayList));
  }

  updateRoomAndAvailability() {

    // 1- Update room Details
    // 2- Update RoomDays

    this.isChangeAvailabilityModalHidden = true;

    // console.log('moment-date = ' + moment(this.beginDate.formatted, 'DD/MM/YYYY').format('YYYY-MM-DD'));

    this.selectedRoom.beginDate = moment(this.beginDate.jsdate, 'YYYY/MM/DD').toDate();
    this.selectedRoom.endDate = moment(this.endDate.jsdate, 'YYYY/MM/DD').toDate();


    this.roomService
      .update(this.selectedRoom)
      .subscribe(
        result => {
          // this.roomList[this.selectedRoomIndex] = this.selectedRoom;
        },
        error => console.log(error),
        () => {
          this.updateRoomDays();
        }
      );
  }

  updateRoomDays() {

    this.roomService.updateRoomDays(this.selectedRoom.id,
      this.selectedRoom.beginDate, this.selectedRoom.endDate,
      this.selectedRoom.unitsAvailable, this.selectedRoom.price)
      .subscribe(result => {
        // this.roomDayList  = result;
          this.loadRoomDaysBy(this.selectedRoom.id);
      },
        error => console.log(error)
      );
  }

  getDateFromJsonString(date) {

    const formattedDate = new Date(date.date.year, date.date.month - 1, date.date.day);
    return formattedDate;
  }

  getJsonStringFromDate(date) {

    console.log('In getJsonStringFromDate = ' + date);
    if (!date) {
      console.log('Date is null');

      return null;
    }
    console.log('Date is not null');
    const array = date.split('-');
    console.log(array);
    let year = '' + array[0];
    year = year.replace('"','');

    const month = array[1];
    const day = array[2].split('T')[0];

    const obj = { date: { year: year, month: month, day: day } };
    return obj;
  }

}
