import { Component, Input, OnInit, ViewEncapsulation, AfterViewInit } from '@angular/core';
import { ScriptLoaderService } from '../../../../_services/script-loader.service';

import {Room} from '../../../../Models/Room';
import {RoomService} from '../../../../Services/Room/room.service';
import {ActivatedRoute, Router} from '@angular/router';
import {RoomType} from '../../../../Models/RoomType';
import {RoomTypeService} from '../../../../Services/RoomType/room-type.service';

@Component({
  selector: 'app-room-form',
  templateUrl: './room-form.component.html',
  encapsulation: ViewEncapsulation.None,
  providers: [RoomService, RoomTypeService]
})
export class RoomFormComponent implements OnInit, AfterViewInit  {
  @Input()
  private roomService: RoomService;
  private roomTypeService: RoomTypeService;
  public roomTypeList: RoomType[];
  errorMessage = '';

  newRoom: Room;

  constructor(roomTypeService: RoomTypeService, roomService: RoomService,
              private route: ActivatedRoute,
              private _script: ScriptLoaderService,
              private router: Router) {

    this.roomService = roomService;
    this.roomTypeService = roomTypeService;
    this.newRoom = new Room();
    this.loadRoomTypes();
  }

    ngOnInit() {}

    ngAfterViewInit() {
        this._script.load('.m-grid__item.m-grid__item--fluid.m-wrapper',
            'assets/demo/default/custom/components/forms/validation/form-widgets.js');
    }
  saveRoomDetails() {
      console.log('Newly Created room:');
    if (this.newRoom.id === '') {
      this.newRoom.id = null;
      this.newRoom.roomType = null;
      this.newRoom.createdTime = new Date();
      this.newRoom.modifiedTime = new Date();
      this.newRoom.modifiedById = 1;
    }

    console.log('Newly Created room: ' + this.newRoom);

    this.roomService
      .add(this.newRoom)
      .subscribe(r => console.log(`saved!!!`),
        error => console.error(''),
        () => this.gotoRoomsList());
  }

  loadRoomTypes() {
    this.roomTypeService
      .getAll()
      .subscribe(
        /* happy path */ roomTypeList => this.roomTypeList = roomTypeList,
        /* error path */ errorMessage => this.errorMessage = errorMessage,
        /* onCompleted */ () => console.log(this.roomTypeList));
  }

  gotoRoomsList() {
    const link = ['/rooms'];
    this.router.navigate(link);
  }
}
